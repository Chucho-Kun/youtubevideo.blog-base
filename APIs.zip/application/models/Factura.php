<?php
defined('BASEPATH') OR exit ('Acceso directo no permitido');

class Detalles_factura extends CI_Model {

	 public $detalle_id;
     public $factura_id;
     public $producto_id;
     public $producto;
     public $precio_unitario;
     public $cantidad;

     public function get_detalles( $id )
     {

     	$this->db->where( 'factura_id' , $id );
     	$detalles = $this->db->get( 'facturacion_detalle' );

     	if( $detalles ){
        		$respuesta = array(
        			'detalles' => $detalles->result()
        		);
        	}else{
        		$respuesta = array(
        			'err' => true,
        			'mensaje' => 'El id: '.$id.' no tiene detalles de Facturación'
        		);
        	}

        return $respuesta;

     }

}



class Factura extends CI_Model {

        public $factura_id;
        public $cliente_id;
        public $Nombre;
        public $total_pagar;

        public function get_factura( $id ){

        	$this->db->where( 'factura_id', $id );
        	$query = $this->db->get('facturacion');
        	//$row = $query->custom_row_object(0, 'Factura');

        	$row = $query->row();

        	if( isset($row) ){
        		$respuesta = array(
        			'err' => false,
        			'mensaje' => 'Usuario válido en base de datos',
        			'tabla_de_facturacion' => $this->Detalles_factura->get_detalles( $id ),
        			'detalles' => $row
        		);
        	}else{
        		$respuesta = array(
        			'err' => true,
        			'mensaje' => 'El id: '.$id.' no se encuentra en la base de datos'
        		);
        	}

                
        	return $respuesta;
        }

      
}

