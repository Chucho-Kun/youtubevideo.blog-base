<?php
defined('BASEPATH') OR exit ('Acceso directo no permitido');

class Gamero_model extends CI_Model
{
		
	public function filtro_consola( $nom , $lista )
	{
		$filtrado = [];

		for ($i=0; $i < count($lista) ; $i++) { 
			if($lista[$i] !== ""){
				$nin = explode("-", $lista[$i]);
				if($nin[0] == $nom){
				array_push($filtrado, $lista[$i]);
			}
			}	
		}

		return $filtrado;
	}

	public function num_consola( $num ){

		$consola = "";

		if( $num == "NS" ){
			$consola = "nintendoswitch";
		}else if( $num == "XBO" ){
			$consola = "xboxone";
		}else if( $num == "PS4" ){
			$consola = "playstation4";
		}

		return $consola;
	}

	public function formato( $num ){

		$formato = "";

		if( $num == "NS" ){
			$formato = ".jpg";
		}else{
			$formato = ".png";
		}

		return $formato;
	}

	public function stock_cnt( $enStock , $buscando ){

        $cnt = 0;
        foreach ($enStock as $key) {

        	$primero = explode(",", $key->stock);

        	for ($i=0; $i < count( $primero ) ; $i++) { 

        		if($primero[$i] == $buscando){ $cnt++;}

        	}
        }

        return $cnt;
	}

	public function precio_final( $tipo , $stock , $porcentaje ){
	
		$precio = false;

		if($tipo == 'oro'){
			
			if( $porcentaje < 50 ){ $precio = '$700'; } // 1/2
			
		}else if($tipo == 'plata'){
			
			if( $porcentaje < 33 ){ $precio = '$300'; } // 1/3
		
		}else if($tipo == 'cobre'){
			
			if( $porcentaje < 25 ){ $precio = '$100'; } // 1/4	
		
		}

		return $precio;

	}

	public function precio_Sucursal( $categoria , $caja = true ){

		$precio = '';

		if( $caja ){

			if( $categoria == 'oro' ){ $precio = '$800'; }
			else if( $categoria == 'plata' ){ $precio = '$400'; }
			else if( $categoria == 'cobre' ){ $precio = '$200'; }

		}else{

			if( $categoria == 'oro' ){ $precio = '$700'; }
			else if( $categoria == 'plata' ){ $precio = '$300'; }
			else if( $categoria == 'cobre' ){ $precio = '$100'; }

		}

		return $precio; 

	}

	public function porConsola( $array , $consola ){  

		$filtrados = [];

		foreach ($array as $a) {
			
			$cn = explode("-", $a);

			if( $cn[0] == $consola ){ array_push( $filtrados , $a ); }

		}

		return $filtrados;
	}

	public function repetidos( $enStock , $buscando ){
		//NS-8,NS-134,NS-20,NS-125,NS-55,NS-106,NS-8,NS-48,NS-8
		//"NS-8"

        $cnt = 0;
        

        	$primero = explode(",", $enStock);

        	for ($i=0; $i < count( $primero ) ; $i++) { 

        		if($primero[$i] == $buscando){ $cnt++;}

        	}
        

        return $cnt;
	}

	public function unicos( $unicos ){

		$unicos = array_unique( $unicos );
        $filtrados = [];

        foreach ($unicos as $uniq){
        	$respuesta = array(
        		"estado" => $uniq
        	);

        	array_push( $filtrados , $respuesta );
        }

        return $filtrados;

	}

	public function nom_url( $nom ){
		//NS-45
		$arr = explode( "-", $nom );

		$consola = $this->num_consola($arr[0]);
		$formato = $this->formato($arr[0]);

		$url = "../portadas/".$consola."/".$arr[1].$formato;

		return $url;

	}

	public function detallesSuc( $estado , $data ){

		$paquete = [];

		foreach ( $data->result() as $d ) {

			if( $d->estado == $estado ){

				$info = array(

					'nombre' => $d->nombre,
					'idnt' => $d->idnt

				); 

				array_push( $paquete , $info );

			}
	
		}

		return $paquete;

	}

	public function suma_canasta( $raw )
	{
		$resp;

		$sumables = array();

		for ($i=0; $i < count($raw) ; $i++) { 
			
			$base = explode("-", $raw[$i]);

			array_push( $sumables , intval( $base[0] ));

		}

		$resp = array_sum( $sumables );
		return $resp;
	}


	public function total( $tipo )
	{
		$resp;

			switch ($tipo){
			  case 'oro_oro':$resp = 100;
				break;
			  case 'oro_plata':$resp = 50;
				break;
			  case 'oro_cobre': $resp = 10;
				break;
			  case 'plata_oro': $resp = 150;
				break;
			  case 'plata_plata':$resp = 100;
				break;
			  case 'plata_cobre':$resp = 50;
				break;
			  case 'cobre_oro': $resp = 600;
				break;
			  case 'cobre_plata':$resp = 150;
				break;
			  case 'cobre_cobre':$resp = 80;
				break;
			}
		
		return $resp;
	}

































}