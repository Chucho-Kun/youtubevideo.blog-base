<?php
defined('BASEPATH') OR exit ('Acceso directo no permitido');

class Precios_model extends CI_Model
{
		
	public function baseCalculo( $base , $tipo )
	{

		$plus = ($base == "registrado") ? 0 : 50 ;
		switch ($tipo){
		//sucursal_usuario   
		  case 'oro_oro':$resp = 100+$plus;
		    break;
		  case 'oro_plata':$resp = 200+$plus;
		    break;
		  case 'oro_cobre': $resp = 700+($plus*2);
		    break;
		  case 'plata_oro': $resp = 50+$plus;
		    break;
		  case 'plata_plata':$resp = 100+$plus;
		    break;
		  case 'plata_cobre':$resp = 500+$plus;
		    break;
		  case 'cobre_oro': $resp = 0+$plus;
		    break;
		  case 'cobre_plata':$resp = 50+$plus;
		    break;
		  case 'cobre_cobre':$resp = 100+$plus;
		    break;
		}

		return $resp;

	}

	public function PI( $tipo )
	{
		switch ($tipo){
  
		  case 'oro':$resp = 20;
		    break;
		  case 'plata':$resp = 20;
		    break;
		  case 'cobre': $resp = 20;
		    break;
		}

		return $resp;

	}

	


































}