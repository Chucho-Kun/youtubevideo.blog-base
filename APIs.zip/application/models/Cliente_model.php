<?php
defined('BASEPATH') OR exit ('Acceso directo no permitido');

class Cliente_model extends CI_Model
{
	public $id;
	public $nombre;
	public $activo;
	public $correo;
	public $zip;
	public $telefono1;
	public $telefono2;
	public $pais;
	public $direccion;
	
	public function get_cliente( $id )
	{

		//$this->db->select('id,nombre');       "correo": null,

		$this->db->where( array( 'id'=> $id, 'status' => 'activo' ) );
		$query = $this->db->get('clientes');
		$row = $query->custom_row_object(0, 'Cliente_model');

		if(isset($row)){
			$row->id      = intval($row->id);
			$row->activo  = intval($row->activo);
		}

		return $row;
	}

	public function set_datos( $data_cruda ){

		foreach ($data_cruda as $nombre_campo => $valor_campo ) {
			 
			if(	property_exists('Cliente_model', $nombre_campo ) ){
				$this->$nombre_campo = $valor_campo;
			}
		}

		if( $this->activo == NULL ){
			$this->activo = 1;
		}

		$this->nombre =  strtoupper( $this->nombre );

		return $this;

	}

	public function insert(){
		
		$query = $this->db->get_where('clientes', array('correo'=> $this->correo));
			$cliente_correo = $query->row();

			if( isset($cliente_correo) ){

				$respuesta = array(
					'err'=>true,
					'mensaje'=>'El correo electronico ya está registrado'
				);

				//$this->response( $respuesta, RestController::HTTP_BAD_REQUEST );

				return $respuesta;
			}

			//$cliente = $this->Cliente_model->set_datos( $data );

			$hecho = $this->db->insert( 'clientes', $this );

			if($hecho){

				$respuesta = array(
					'err' => false,
					'mensaje' => 'Registro insertado correctamente',
					'cliente_id' => $this->db->insert_id()
				);

				//$this->response( $respuesta );

				}else{

				$respuesta = array(
					'err' => true,
					'mensaje' => 'Error al insertar',
					'error' => $this->db->error_message(),
					'error_num'=> $this->db->error_number()
				);

				//$this->response( $respuesta, RestController::HTTP_INTERNAL_SERVER_ERROR );

			}
			return $respuesta;

	}



	public function update(){

		// recibir un correo que exista para modificarlo

		$query = $this->db->get_where('clientes', array('correo =' => $this->correo, 'id !=' => $this->id ));

		$cliente_correo = $query->row();

		if( isset($cliente_correo) ){

			$respuesta = array(
				'err'=>true,
				'mensaje'=>'El correo electronico ya está registrado por otro usuario'
			);

			return $respuesta;
		}

		$this->db->reset_query();

		$this->db->where( 'id', $this->id );

		$hecho = $this->db->update( 'clientes', $this );

		if( $hecho ){

			$respuesta = array(
					'err' => false,
					'mensaje' => 'Registro actualizado correctamente',
					'cliente_id' => $this->id
			);

			}else{

				$respuesta = array(
					'err' => true,
					'mensaje' => 'Error al actualizar',
					'error' => $this->db->error_message(),
					'error_num'=> $this->db->error_number()
				);

		//$this->response( $respuesta, RestController::HTTP_INTERNAL_SERVER_ERROR );

		}
		return $respuesta;
	}





	public function delete( $cliente_id ){
		
		$this->db->set( 'status' , 'borrado' );
		$this->db->where( 'id', $cliente_id );
		$hecho = $this->db->update( 'clientes' );

		if( $hecho ){
			//Borrar
			$respuesta = array(
					'err' => false,
					'mensaje' => 'Registro eliminado correctamente',
					'cliente_id' => $this->id
			);

			}else{

				$respuesta = array(
					'err' => true,
					'mensaje' => 'Error al borrar',
					'error' => $this->db->error_message(),
					'error_num'=> $this->db->error_number()
				);

		//$this->response( $respuesta, RestController::HTTP_INTERNAL_SERVER_ERROR );

		}

		return $respuesta;

	}
}








































