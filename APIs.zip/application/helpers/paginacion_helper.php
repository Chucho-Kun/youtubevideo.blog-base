<?php

function paginar_todo( $tabla, $pagina = 1, $por_pagina = 20 ){

		$CI =& get_instance();
		$CI->load->database();

		if(! isset( $por_pagina )){
			$por_pagina = 20;
		}

		if(! isset( $pagina )){
			$pagina = 1;
		}


		$cuantos = $CI->db->count_all( $tabla );
		$total_paginas = ceil( $cuantos / $por_pagina );


		if( $pagina > $total_paginas ){
			$pagina = $total_paginas;
		}

		$pagina -= 1;
		$desde = $pagina * $por_pagina;

		
		if( $pagina >= $total_paginas - 1 ){
			$pag_siguiente = 1;
		}else{
			$pag_siguiente = $pagina + 2 ;
		}


		if( $pagina < 1 ){
			$pagina_anterior = $total_paginas;
		}else{
			$pagina_anterior = $pagina;
		}


		$CI->db->select( array('nombre','id','direccion') );
		
		$query = $CI->db->get( $tabla , $por_pagina, $desde );
		//$query = $CI->db->get(' clientes ', $por_pagina, $desde);

		$respuesta = array(
			'err' => false,
			'cuantos' => $cuantos,
			'total_paginas' => $total_paginas,
			'pag_anterior' => $pagina_anterior,
			'pagina_actual' => ($pagina + 1),
			'pag_siguiente' => $pag_siguiente,
			$tabla => $query->result()

		);

		return $respuesta;

}

?>