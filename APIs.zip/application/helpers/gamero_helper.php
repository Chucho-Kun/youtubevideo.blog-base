<?php

function unicos( $raw ){



    foreach ($raw as $nom) {
		
        $respuesta = $nom;

    }
		return $respuesta;

}

?>