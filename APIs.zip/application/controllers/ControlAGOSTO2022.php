<?php
defined('BASEPATH') OR exit ('Acceso directo no permitido');

require( APPPATH.'/libraries/RestController.php');
require( APPPATH.'/libraries/Format.php');
use chriskacerguis\RestServer\RestController;


class Control extends RestController {

	public function __construct(){

		parent::__construct();
		$this->load->database();

	}

	public function saludo_get(){

		echo "CONEXION LISTA";

	}

    public function controldeCanales_get(){

        $this->db->select();
        $this->db->from( "usuarios" );

        $resultado = $this->db->get();
        $encontrado = $resultado->row();

        if( isset( $encontrado ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No hay datos' 
             );

        }

        $this->response( $respuesta );

    }

	public function nuevoRegistro_post(){

		$dat = $this->post();
		$nombreCanal = $dat['nombreCanal'];
		$idCanal = $dat['idCanal'];
		$correo = $dat['correo'];
		$avatar = $dat['avatar'];
		$startSubs = $dat['startSubs'];

		$array = array( 'nombreCanal' => $nombreCanal , 'idCanal' => $idCanal , 'correo' => $correo , 'avatar' => $avatar , 'startSubs' => $startSubs );

		$r = $this->db->insert( 'usuarios' , $array );
		$nuevoID = $this->db->insert_id();

		if( $r == "1" ){

			$respuesta = array( 'status' => true, 'nombreCanal' => $nombreCanal, 'id' => $nuevoID , 'correo' => $correo , 'avatar' => $avatar , 'msn' => 'registro exitoso' );

		}else{

			$respuesta = array( 'status' => false, 'nombreCanal' => '' , 'id' => '0' , 'correo' => '' , 'avatar' => '' , 'msn' => 'falló el registro' );

		}

		$this->response( $respuesta );

	}

		public function canalYaRegistrado_post(){

		$usr = $this->post();
		$revisar = $usr['idCanal'];

		$this->db->select();
        $this->db->from( "usuarios" );
        $this->db->where( "idCanal" , $revisar );

        $resultado = $this->db->get();
        $encontrado = $resultado->row();

		if( isset( $encontrado ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'El Canal no se encontra registrado' 
             );

        }

        $this->response( $respuesta );


	}
	

	public function buscarUsuario_post(){

		$usr = $this->post();
		$correo = $usr['usuario'];

		$this->db->select( "id, nombreCanal, idCanal, avatar, correo" );
        $this->db->from( "usuarios" );
        $this->db->where( "correo" , $correo );

        $resultado = $this->db->get();
        $encontrado = $resultado->row();

		if( isset( $encontrado ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se encontra registrado' 
             );

        }

        $this->response( $respuesta );


	}

	public function leeLista_post(){

		$yo = $this->post();
		$miID = $yo['id'];

		$this->db->select();
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $miID );

        $resultado = $this->db->get();
        $valido = $resultado->row();

        if( isset( $valido ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se encontraron resultados' 
             );

        }

        $this->response( $respuesta );

	}

	public function apoyaCanales_post(){

		$yo = $this->post();
		$miID =  $yo['id'];
		$apoyadosString = $yo['apoyados'];

		$this->db->select( "id, idCanal , nombreCanal , brecha, suscriptores , avatar" );
        $this->db->from( "usuarios" );

        $apoyados = explode(",", $apoyadosString);
        array_push($apoyados, $miID);
        $this->db->where( "visible" , "1" );
		$this->db->where_not_in('id', $apoyados);
        //$this->db->order_by("brecha");
        $this->db->order_by("suscriptores" , "DESC");
        $this->db->limit(20);

        $resultado = $this->db->get();
        $valido = $resultado->row();

        if( isset( $valido ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se encontraron resultados' 
             );

        }

        $this->response( $respuesta );

	}

	public function apoyaVerificados_post(){

		$yo = $this->post();
		$apoyadosString = $yo['apoyados'];

		$this->db->select( "id, idCanal , nombreCanal , brecha, avatar" );
        $this->db->from( "usuarios" );

        $apoyados = explode(",", $apoyadosString);
        //$this->db->where( "visible" , "1" );
		$this->db->where_in('id', $apoyados);
        //$this->db->order_by("brecha");
        //$this->db->limit(20);

        $resultado = $this->db->get();
        $valido = $resultado->row();

        if( isset( $valido ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se encontraron resultados' 
             );

        }

        $this->response( $respuesta );

	}

	public function usuariosActivos_get(){

		$this->db->select( "id" );
        $this->db->from( "usuarios" );
        $this->db->where( "visible" , "1" );
        $resultado = $this->db->get();
        $total = $resultado->num_rows();

         $respuesta = array(
                'error' => false ,
                 'total' => $total-1 
             );

        $this->response( $respuesta );

	}

	/*reemplazaable*/
	public function apoyados_post(){

		$nuevos = $this->post();
		$miId = $nuevos['miId'];

		$this->db->select( "apoyados" );
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $miId );

        $resultado = $this->db->get();
        $anteriores = $resultado->row();

        if( isset( $anteriores ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se pudo recuperar resultados' 
             );

        }

        $this->response( $respuesta );

	}

	public function verificados_post(){

		$nuevos = $this->post();
		$miId = $nuevos['miId'];

		$this->db->select( "verificados , apoyados" );
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $miId );

        $resultado = $this->db->get();
        $anteriores = $resultado->row();

        if( isset( $anteriores ) ){

            $respuesta = array(
                'error' => false,
                 'info' => $resultado->result()
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se pudo recuperar resultados' 
             );

        }

        $this->response( $respuesta );

	}

	public function misApoyados_post(){

		/*primero lees los apoyados de origen y de destino*/
		/* luego actualizas en origen con destino y viceversa*/

		$x = $this->post();
		$origen = $x['origen'];
		$destino = $x['destino'];

		$this->db->select( "apoyados" );
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $origen );

        $resultado = $this->db->get();

        foreach ($resultado->result() as $orig){

        	$origApoyadosStr = $orig->apoyados; //A,B,C

        	$origApoyados = ( $origApoyadosStr == '' ) ? array() : explode(',', $origApoyadosStr) ;
        	array_push( $origApoyados , $destino );
        	$unicos = array_unique( $origApoyados );
        	$newOrigApoyados = implode(',', $unicos);

        	$this->db->set('apoyados', $newOrigApoyados);
			$this->db->where('id', $origen);
			$this->db->update('usuarios');

        }

        $this->db->select( "apoyados" );
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $destino );

        $respuesta = $this->db->get();

        foreach ($respuesta->result() as $resp){

        	$origApoyadosStr = $resp->apoyados; //4,5,6

        	$origApoyados = ( $origApoyadosStr == '' ) ? array() : explode(',', $origApoyadosStr) ;
        	array_push( $origApoyados , $origen );
        	$unicos = array_unique( $origApoyados );
        	$newOrigApoyados = implode(',', $unicos);

        	$this->db->set('apoyados', $newOrigApoyados);
			$this->db->where('id', $destino);
			$this->db->update('usuarios');

        }

	}


	/*reemplazable*/
	public function actualizaApoyados_post(){

		$data = $this->post();
		$concentrado = $data['concentrado'];
		$miId = $data['miId'];

        //$this->db->set('apoyados', $concentrado);

		$this->db->set('apoyados', $concentrado);
		$this->db->where('id', $miId);
		$r = $this->db->update('usuarios');

        if( isset( $r ) ){

            $respuesta = array(
                'error' => false,
                 'info' => 'información actualizada correctamente'
            );

        }else{

            $respuesta = array(
                'error' => true ,
                 'info' => 'No se pudo actualizar la informacion' 
             );

        }

        $this->response( $respuesta );

	}

	public function actualizaVerificados_post(){

		$data = $this->post();
		$concentrado = $data['concentrado'];
		$miId = $data['miId'];
		$especial = $data['especial'];

        //$this->db->set('apoyados', $concentrado);

        $this->db->select("id , teSuscribiste , suscriptores");
        $this->db->from( "usuarios" );
        $this->db->where( 'id' , $miId );
        $resultado = $this->db->get();

        $analista = array();

        foreach ($resultado->result() as $res){

        	$cntAnt = $res->teSuscribiste;
        	$subs = $res->suscriptores;
        	$teSuscribiste = intval( $cntAnt ) + 1;
        	$numSubs = intval( $subs );
        	
        }

    	$informacion = ( $especial ) ? array( 'teSuscribiste' => $teSuscribiste ) : array('verificados' => $concentrado , 'teSuscribiste' => $teSuscribiste );
      
		$this->db->set( $informacion );
		$this->db->where('id', $miId);
		$r = $this->db->update('usuarios');
		// origen se buscara destino en verificado
		$brecha = $teSuscribiste - $numSubs;

        if( isset( $r ) ){ $respuesta = array( 'error' => false, 'info' => 'información actualizada correctamente' , 'brecha' => $brecha ); }else{ $respuesta = array( 'error' => true , 'info' => 'No se pudo actualizar la informacion' ); }

        if( $brecha >= 8 ){

        	$this->db->set( "visible" , "0" );
			$this->db->where('id', $miId);
			$r = $this->db->update('usuarios');

        }	

        $this->response( $respuesta );

	}

	public function corrigeEvidencias_post(){

		$p = $this->post();
		$origen = $p['origen'];
		$destino = $p['destino'];
		$mensaje = $p['mensaje'];

		$this->db->select(" id , apoyados , comentarios ");
        $this->db->from( "usuarios" );

        $this->db->where( "id='".$origen."' OR id='".$destino."'" );
        $resultado = $this->db->get();

        $analista = array();

        foreach ($resultado->result() as $res){
        	$id = $res->id;
        	$dato = array( 'id' => $res->id , 'apoyados' => $res->apoyados , 'comentarios' => $res->comentarios );
			array_push( $analista , $dato );
        }

        $A = $analista[0]['id'];
        $vA = $analista[0]['apoyados'];
        $msnA = $analista[0]['comentarios'];
        $arrayA = explode(',', $vA);

        $B = $analista[1]['id'];
        $vB = $analista[1]['apoyados'];
        $arrayB = explode(',', $vB);
    
        $newArrayA = array();
        $newArrayB = array();

        	for ($i=0; $i < count($arrayA) ; $i++){ if( $arrayA[$i] !== $B ){ array_push( $newArrayA , $arrayA[$i] );} }
        	for ($i=0; $i < count($arrayB) ; $i++){ if( $arrayB[$i] !== $A ){ array_push( $newArrayB , $arrayB[$i] );} }

        	 $newA = implode(',', $newArrayA);

    		 $nuevoMsnRaw = '[{"id":"'.$destino.'","msn":"'.$mensaje.'"}]';
        	 //$nuevoMsnRaw = '[{"id":"1","msn":"error validado"}]';
			 $jsonMsn = json_decode($msnA);
			 $nuevoMsn = json_decode($nuevoMsnRaw);
			 
			 $totalMensajes = array();
			 
			 foreach ($jsonMsn as $json ){
			     
			     $id = $json->id; $msn = $json->msn;
			     $datos = array( "id" => $id , "msn" => $msn );
			     array_push( $totalMensajes , $datos);
			     
			 }
			 
			  foreach ($nuevoMsn as $json ){
			     
			     $id = $json->id; $msn = $json->msn;
			     $datos = array( "id" => $id , "msn" => $msn );
			     array_push( $totalMensajes , $datos);
			     
			 }
			 
			$mensajesTotales = json_encode($totalMensajes);

        $this->db->set( 'apoyados' , $newA );
		$this->db->where('id', $A);
		$this->db->update('usuarios');

		$newB = implode(',', $newArrayB);
			//MENSAJE
        $this->db->set( 'apoyados' , $newB );
		$this->db->where('id', $B);
		$this->db->update('usuarios');

		$this->db->set( 'comentarios' , $mensajesTotales );
		$this->db->where('id', $origen);
		$this->db->update('usuarios');

        $this->response( $nuevoMsnRaw );

	}

	public function corrigeDuplicidades_post(){

		$p = $this->post();
		$origen = $p['usuario'];
		$destino = $p['destino'];

		$this->db->select("id,verificados");
        $this->db->from( "usuarios" );

        $this->db->where( "id='".$origen."' OR id='".$destino."'" );
        $resultado = $this->db->get();

        $analista = array();

        foreach ($resultado->result() as $res){

        	$id = $res->id;
        	$dato = array( 'id' => $res->id , 'verificados' => $res->verificados );
			array_push( $analista , $dato );
        }

        $A = $analista[0]['id'];
        $vA = $analista[0]['verificados'];
        $arrayA = explode(',', $vA);

        $B = $analista[1]['id'];
        $vB = $analista[1]['verificados'];
        $arrayB = explode(',', $vB);
        //evaluando coincidencias
        $ResultadoA = in_array( $A , $arrayB );
        $ResultadoB = in_array( $B , $arrayA );

        $newArrayA = array();
        $newArrayB = array();

        $mensaje = "No se detecto duplicidad";

        if( $ResultadoA && $ResultadoB ){

        	$mensaje = "Duplicidad detectada se borraran las peticiones";

        	for ($i=0; $i < count($arrayA) ; $i++){ if( $arrayA[$i] !== $B ){ array_push( $newArrayA , $arrayA[$i] );} }
        	for ($i=0; $i < count($arrayB) ; $i++){ if( $arrayB[$i] !== $A ){ array_push( $newArrayB , $arrayB[$i] );} }

        	$newA = implode(',', $newArrayA);

        	$this->db->set('verificados', $newA);
			$this->db->where('id', $A);
			$this->db->update('usuarios');

			$newB = implode(',', $newArrayB);

        	$this->db->set('verificados', $newB);
			$this->db->where('id', $B);
			$this->db->update('usuarios');

        }

        $this->response( array('mensaje' => $mensaje ) );

	}

	public function sumaPuntos_post(){

		$p = $this->post();
		$origen = $p['lista'];
		$destino = $p['destino'];

		$this->db->select();
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $origen );

        $resultado = $this->db->get();
        $anteriores = $resultado->row();

        $resultadosFinales = array();

        foreach ($resultado->result() as $res){

        	$teSuscribiste = $res->teSuscribiste;
        	$teSuscribisteList = $res->teSuscribisteList;
			$subsAnt = $res->suscriptores;
			$idnt = $res->id;
			$subs = intval( $subsAnt ) + 1;
			$comentarios = $res->comentarios;


			if( $subs > 0 && $subs < 21 ){

				$insignia = 'A';

			}else if( $subs > 20 && $subs < 51 ){

				$insignia = 'A,B';

			}else if( $subs > 50 && $subs < 101 ){

				$insignia = 'A,B,C';

			}else if( $subs > 100 && $subs < 201 ){

				$insignia = 'A,B,C,D';

			}else if( $subs > 200 && $subs < 351 ){

				$insignia = 'A,B,C,D,E';

			}else if( $subs > 350 && $subs < 501 ){

				$insignia = 'A,B,C,D,E,F';

			}else if( $subs > 600 && $subs < 801 ){

				$insignia = 'A,B,C,D,E,F,A+';

			}else if( $subs > 800 && $subs < 1001 ){

				$insignia = 'A,B,C,D,E,F,A+,B+';

			}else if( $subs > 1000 && $subs < 2001 ){

				$insignia = 'A,B,C,D,E,F,A+,B+,C+';

			}else{

				$insignia = '';

			}

			$apoyadosString = $res->apoyados;
			$membresia = $res->suscripcion;

			$apoyados = ( $apoyadosString == '' ) ? 0 : explode( "," , $apoyadosString);
			//$valido = ( $apoyados == 0 ) ? 0 : count( $apoyados ) ; 
			//$brecha = $subs - $valido;
			//$brecha = ( $membresia ) ? -999 : $subs - $valido ; 
			$brecha = intval( $teSuscribiste ) - $subs;

			if( $comentarios == '' ){

				$nuevoComentario = '';

			}else{

				$jsonMsn = json_decode($comentarios);
				$totalMensajes = array();

				foreach ($jsonMsn as $json ){
					     
					$id = $json->id; 
					$msn = $json->msn;

					$datos = array( "id" => $id , "msn" => $msn );
					if( $json->id !== strval($destino) ){ array_push( $totalMensajes , $datos); }
					     
				}
					 
				$nuevoComentario = ( count( $totalMensajes ) == 0 ) ? '' : json_encode($totalMensajes) ;
				//$nuevoComentario = json_encode( $totalMensajes);

			}

			$dato = array( 'status' => true , 'id' => $res->id , 'subs' => $subs , 'apoyadosString' => $apoyadosString , 'brecha' => $brecha , 'comentarios' => $comentarios , 'comentariosCnt' => count( $totalMensajes ) , 'objetivo' => $origen , 'destino' => $destino );
			array_push( $resultadosFinales , $dato );

			$originales = ( $teSuscribisteList == '' ) ? array() : explode(',', $teSuscribisteList); 
			array_push( $originales , strval($destino) );
			$newSubsList = implode(',', $originales);

			$nuevaData = array( 'suscriptores' => $subs , 'insignia' => $insignia , 'comentarios' => $nuevoComentario , 'teSuscribisteList' => $newSubsList );
			$this->db->set( $nuevaData );
			$this->db->where('id', $idnt);
			$this->db->update('usuarios');

        if( $brecha < 8 ){

        	$this->db->set( "visible" , "1" );
			$this->db->where('id', $origen);
			$r = $this->db->update('usuarios');

        }

		}

        $this->response( $resultadosFinales );

	}

	public function ajustaMiBrecha_post(){

		$p = $this->post();
		$miId = $p['miId'];

		$this->db->select();
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $miId );

        $resultado = $this->db->get();

        $resultadosFinales = array();

        foreach ($resultado->result() as $res){

			$subsAnt = $res->suscriptores;
			$idnt = $res->id;
			$subs = intval( $subsAnt );
			$apoyadosString = $res->apoyados;

			$apoyados = ( $apoyadosString == '' ) ? 0 : explode( "," , $apoyadosString);
			$valido = ( $apoyados == 0 ) ? 0 : count( $apoyados ) ; 

			$brecha = $subs - $valido;

			$dato = array( 'status' => true , 'id' => $res->id , 'subs' => $subs , 'apoyadosString' => $apoyadosString , 'brecha' => $brecha );
			array_push( $resultadosFinales , $dato );

			$this->db->set( 'brecha' , $brecha );
			$this->db->where('id', $idnt);
			$this->db->update('usuarios');

		}

        $this->response( $resultadosFinales );

	}


	public function evidenciaApoyados_post(){

		$p = $this->post();
		$listaRaw = $p['lista'];
		$lista = explode(",", $listaRaw);

		$this->db->select();
        $this->db->from( "usuarios" );
        $this->db->where_in( "id" , $lista );

        $resultado = $this->db->get();

        $resultadosFinales = array();

        foreach ($resultado->result() as $res){

			$dato = array( 'id' => $res->id , 'idCanal' => $res->idCanal );
			array_push( $resultadosFinales , $dato );

		}

        $this->response( $resultadosFinales );

	}

	public function borraPendientes_post(){

		$p = $this->post();
		$miId = $p['miId'];
		$objetivo = $p['usuario'];

		$this->db->select('verificados');
        $this->db->from( "usuarios" );
        $this->db->where( "id" , $miId );

        $resultado = $this->db->get();

        foreach ($resultado->result() as $res){

			$anteriores = $res->verificados;
			$nuevos = array();

			$ant = explode(',', $anteriores);
			for ($i=0; $i < count($ant); $i++) { if( $ant[$i] !== $objetivo ){ array_push($nuevos, $ant[$i]); } }

			$nuevoStr = implode(',', $nuevos);
		   
			$this->db->set( 'verificados' , $nuevoStr );
			$this->db->where('id', $miId);
			$this->db->update('usuarios');

		}

		$resp = array('error' => false , 'txt' => 'Información actualizada' );
        $this->response( $resp );

	}















    public function data_get( $consola ){

		$query = $this->db->get( $consola );

		foreach( $query->result() as $row ){
			echo  $row->ID . " - " .$row->Nombre . '<br/>' ;
		}

		
		
		//echo json_encode( $query->result() );

		//$this->response( $query->result() );


		//$id = $this->get();
		//$this->db->where( 'id', $id );

		//$this->load->helper('gamero');

		/*$respuesta = array(
			'id' => 9,
			'nom' => 'NS-9',
			'nombre' => 'VOEZ',
			'tipo' => 'plata',
			'desarrolladora' => 'nintendo',
			'upc' => '883929580224',
			'categoria' => 'Puzzles'
		);*/

		//$this->response( $respuesta );        
        

	}

	public function listaCompleta_get( $tabla ){

		$query = $this->db->get( $tabla );
			$respuesta = array(
				'error' => false,
				'mensaje' => 'Datos encontrados',
				'totales' => $query->num_rows(),
				'respuesta' => $query->result()
			); 
		$this->response( $respuesta );
	}

	public function agregaRegistro_post(){

		$d = $this->post();	

		$nombre_consola = $this->Gamero_model->num_consola( $d["nom"] );

		$ultimoId = $this->db->query( 'SELECT MAX(ID) AS id FROM '.$nombre_consola );

		$raw = $ultimoId->result();
		
		$cnt = intval( $raw[0]->id ); //"135"
		$cnt++;

		$array = array(

			'ID' => $cnt,
			'Nombre' => $d["nombre"],
			'Tipo' => $d["tipo"],
			'Desarrolladora' => $d["desarrolladora"],
			'UPC' => $d["upc"],
			'Categoria' => $d["categoria"],
			'Revision' => 'revisar'

		);

		$r = $this->db->insert( $nombre_consola , $array );

		if( $r == "1" ){

			$respuesta = array(

				'id' => strval( $cnt ),
				'result' => true,
				'consola' => $nombre_consola

			);

		}else{

			$respuesta = array(

				'id' => 'X',
				'result' => false,
				'consola' => false

			);

		}

		$this->response( $respuesta );

	}

}

?>








































